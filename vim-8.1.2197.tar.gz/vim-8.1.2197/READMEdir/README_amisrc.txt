README_amisrc.txt for version 8.1 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_ami.txt" for installation instructions for the Amiga.
These files are in the runtime archive (vim81rt.tgz).


The Amiga source archive contains the files needed to compile Vim on the
Amiga.

See "src/INSTALLami.txt" for instructions on how to compile Vim on the Amiga.
